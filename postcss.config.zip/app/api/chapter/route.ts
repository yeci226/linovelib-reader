import { NextRequest, NextResponse } from "next/server";
import * as cheerio from "cheerio";
import { cfFetchHtml } from "@/lib/cf-fetch";
import { readCache, writeCache } from "@/lib/cache";
import { setTimeout as sleep } from "node:timers/promises";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// 章節內容永久快取（linovelib 已發布章節不會變）
const CHAPTER_TTL_MS: number | null = null;
// 抓多頁時每頁間延遲，避免被限流
const PAGE_DELAY_MS = 1500;
const MAX_PAGES = 20;

type ChapterResult = {
  title: string;
  content: string;
  pages: number;
};

function extractPage(html: string, currentUrl: string): { title: string; content: string; nextUrl: string | null } {
  const $ = cheerio.load(html);
  $("script, style, ins, iframe, .ads, #ads").remove();

  const title = $("h1").first().text().trim() || "";

  const contentEl = $("#mlfy_main_text, .read-content, .chapter-content, #TextContent").first();
  let content = "";
  if (contentEl.length) {
    contentEl.find("p").each((_, el) => {
      const text = $(el).text().trim();
      if (text) content += text + "\n\n";
    });
  }

  const baseUrl = new URL(currentUrl);
  const chapterBase = baseUrl.pathname.replace(/_\d+\.html$/, "").replace(/\.html$/, "");
  let nextUrl: string | null = null;
  $("a").each((_, el) => {
    if (nextUrl) return;
    const href = $(el).attr("href") || "";
    const text = $(el).text().trim();
    if (!href || !text.includes("下一頁")) return;
    const nextPath = href.startsWith("http") ? new URL(href).pathname : href;
    if (nextPath.startsWith(chapterBase)) {
      nextUrl = href.startsWith("http") ? href : baseUrl.origin + href;
    }
  });

  return { title, content: content.trim(), nextUrl };
}

export async function GET(req: NextRequest) {
  const url = req.nextUrl.searchParams.get("url");
  const force = req.nextUrl.searchParams.get("refresh") === "1";
  if (!url) return NextResponse.json({ error: "Missing url" }, { status: 400 });

  try {
    if (!force) {
      const cached = await readCache<ChapterResult>("chapter", url);
      if (cached) return NextResponse.json({ ...cached, cached: true });
    }

    let title = "章節";
    let allContent = "";
    let currentUrl: string | null = url;
    let pageCount = 0;

    while (currentUrl && pageCount < MAX_PAGES) {
      if (pageCount > 0) await sleep(PAGE_DELAY_MS);
      const html: string = await cfFetchHtml(currentUrl);
      const { title: pageTitle, content, nextUrl } = extractPage(html, currentUrl);
      if (pageCount === 0 && pageTitle) title = pageTitle;
      allContent += content + "\n\n";
      currentUrl = nextUrl;
      pageCount++;
    }

    const result: ChapterResult = {
      title,
      content: allContent.trim(),
      pages: pageCount,
    };
    await writeCache("chapter", url, result, CHAPTER_TTL_MS);
    return NextResponse.json({ ...result, cached: false });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
