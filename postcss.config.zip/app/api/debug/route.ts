
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const url = "https://tw.linovelib.com/novel/2139/catalog";
  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
        "Accept": "text/html,application/xhtml+xml",
        "Accept-Language": "zh-TW,zh;q=0.9",
        "Referer": "https://tw.linovelib.com/",
      },
    });
    const html = await res.text();
    // Return first 2000 chars and h1/a count
    const h1Match = html.match(/<h1[^>]*>([^<]*)<\/h1>/);
    const aMatches = (html.match(/href="[^"]*\/novel\/\d+\/\d+\.html"/g) || []).slice(0,5);
    return NextResponse.json({
      status: res.status,
      htmlLen: html.length,
      h1: h1Match?.[1] || "none",
      sampleLinks: aMatches,
      htmlStart: html.substring(0, 500),
    });
  } catch(e) {
    return NextResponse.json({ error: String(e) });
  }
}
