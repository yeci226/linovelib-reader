import { NextRequest } from "next/server";

export const runtime = "nodejs";

const TTL_MS = 24 * 60 * 60 * 1000; // 1 day
const BROWSER_CACHE_SEC = 60 * 60;   // 1 hour browser cache
const MAX_ENTRIES = 500;

type CacheEntry = { html: string; status: number; ts: number };
const cache = new Map<string, CacheEntry>();

function pruneCache() {
  if (cache.size <= MAX_ENTRIES) return;
  // Evict oldest entries
  const sorted = [...cache.entries()].sort((a, b) => a[1].ts - b[1].ts);
  for (const [key] of sorted.slice(0, cache.size - MAX_ENTRIES)) {
    cache.delete(key);
  }
}

function makeHeaders(xCache: string, status: number): Record<string, string> {
  const headers: Record<string, string> = {
    "Content-Type": "text/html; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "X-Cache": xCache,
  };
  // Let the browser cache successful responses for 1 hour so re-reading a chapter
  // within the same session doesn't hit the server at all.
  if (status >= 200 && status < 300) {
    headers["Cache-Control"] = `public, max-age=${BROWSER_CACHE_SEC}`;
  }
  return headers;
}

async function fetchWithRetry(url: string, retries = 2): Promise<{ html: string; status: number }> {
  const headers = {
    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-TW,zh;q=0.9,en;q=0.8",
    "Referer": "https://tw.linovelib.com/",
  };

  for (let attempt = 0; attempt <= retries; attempt++) {
    if (attempt > 0) {
      await new Promise(r => setTimeout(r, 600 * attempt));
    }
    const res = await fetch(url, { headers });
    const html = await res.text();
    if (res.status !== 429) return { html, status: res.status };
    // On 429, continue retrying
  }
  return { html: "Rate limited", status: 429 };
}

export async function GET(req: NextRequest) {
  const url = req.nextUrl.searchParams.get("url");
  if (!url) return new Response("Missing url", { status: 400 });

  const now = Date.now();

  // Return cached entry if fresh
  const hit = cache.get(url);
  if (hit && now - hit.ts < TTL_MS) {
    return new Response(hit.html, {
      status: hit.status,
      headers: makeHeaders("HIT", hit.status),
    });
  }

  const { html, status } = await fetchWithRetry(url);

  // On 429 with a stale cache entry, serve stale rather than failing
  if (status === 429 && hit) {
    return new Response(hit.html, {
      status: hit.status,
      headers: makeHeaders("STALE", hit.status),
    });
  }

  // Cache successful (2xx) or expected non-success responses
  if (status !== 429) {
    cache.set(url, { html, status, ts: now });
    pruneCache();
  }

  return new Response(html, {
    status,
    headers: makeHeaders("MISS", status),
  });
}
