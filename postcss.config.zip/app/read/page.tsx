"use client";
import { useEffect, useState, useRef, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import {
  saveProgress,
  getEntryFor,
  markChapterVisited,
  getCachedChapterTitle,
  addBookmark,
  getBookmarksForChapter,
  removeBookmark,
  Bookmark,
} from "@/lib/history";

const IMAGE_PROXY = (src: string) => `/api/image?url=${encodeURIComponent(src)}`;

async function fetchHtml(url: string): Promise<string> {
  const res = await fetch(`/api/proxy?url=${encodeURIComponent(url)}`);
  return res.text();
}

type ContentNode = { type: "text"; text: string } | { type: "image"; src: string; alt: string };

interface ReadParams {
  url_previous?: string;
  url_next?: string;
  url_image?: string;
  chaptername?: string;
}

function parseReadParams(html: string): ReadParams {
  const extract = (key: string): string | undefined => {
    const re = new RegExp(`["']?${key}["']?\\s*:\\s*["']([^"']+)["']`);
    return html.match(re)?.[1];
  };

  const result: ReadParams = {};
  const urlNext = extract("url_next");
  const urlPrev = extract("url_previous");
  const urlImage = extract("url_image");
  const chaptername = extract("chaptername");
  if (urlNext) result.url_next = urlNext;
  if (urlPrev) result.url_previous = urlPrev;
  if (urlImage) result.url_image = urlImage;
  if (chaptername) result.chaptername = chaptername;

  if (!urlNext && !urlPrev) {
    const m = html.match(/var\s+ReadParams\s*=\s*(\{[\s\S]*?\});?/);
    if (m) {
      try {
        // eslint-disable-next-line no-new-func
        const parsed = new Function(`return ${m[1]}`)() as ReadParams;
        if (parsed && typeof parsed === "object") return parsed;
      } catch { /* ignore */ }
    }
  }

  return result;
}

function parseChapterPage(html: string, currentUrl: string): {
  title: string;
  subtitle: string;
  nodes: ContentNode[];
  nextUrl: string | null;
  prevUrl: string | null;
  isNextPageSameChapter: boolean;
} {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  doc.querySelectorAll("script, style, ins, iframe, .ads, #ads, center, .cgo").forEach(el => el.remove());

  const ERROR_RE = /（[^）]*加載失敗[^）]*）|（[^）]*請重載[^）]*）/g;

  const title = doc.querySelector("h1#atitle")?.textContent?.trim()
    || doc.querySelector("h1")?.textContent?.trim()
    || "章節";

  const subtitle = (() => {
    const crumbs = [...doc.querySelectorAll(".read-bread a, .breadcrumb a, nav.crumb a")];
    if (crumbs.length >= 2) {
      const t = crumbs[crumbs.length - 2].textContent?.trim() ?? "";
      if (t && t !== title) return t;
    }
    const h2 = doc.querySelector("h2")?.textContent?.trim() ?? "";
    if (h2 && h2 !== title) return h2;
    return "";
  })();

  const getRealSrc = (img: Element): string => {
    const dataSrc = img.getAttribute("data-src") || "";
    const src = img.getAttribute("src") || "";
    const real = dataSrc || src;
    if (!real || real.endsWith(".svg") || real.includes("sloading")) return "";
    return real;
  };

  const contentEl = doc.getElementById("acontent");

  const nodes: ContentNode[] = [];
  if (contentEl) {
    const hiddenDiv = contentEl.querySelector("#hidden-images");
    const allImgEls: Element[] = [];

    contentEl.childNodes.forEach(node => {
      if (node.nodeType === Node.ELEMENT_NODE) {
        const el = node as Element;
        if (el.id === "hidden-images") return;
        if (el.tagName === "P") {
          el.querySelectorAll("center, [style*='color:red'], [style*='color: red']").forEach(e => e.remove());
          const imgs = el.querySelectorAll("img");
          if (imgs.length > 0) {
            imgs.forEach(img => {
              const src = getRealSrc(img);
              if (src) nodes.push({ type: "image", src, alt: img.getAttribute("alt") || "" });
            });
          } else {
            const raw = el.textContent?.trim() ?? "";
            const text = raw.replace(ERROR_RE, "").trim();
            if (text) nodes.push({ type: "text", text });
          }
        } else if (el.tagName === "IMG") {
          const src = getRealSrc(el);
          if (src) nodes.push({ type: "image", src, alt: el.getAttribute("alt") || "" });
        } else if (el.tagName === "DIV" || el.tagName === "SECTION") {
          el.querySelectorAll("img").forEach(img => {
            const src = getRealSrc(img);
            if (src) nodes.push({ type: "image", src, alt: img.getAttribute("alt") || "" });
          });
        }
      }
    });

    if (hiddenDiv) {
      hiddenDiv.querySelectorAll("img").forEach(img => {
        const src = getRealSrc(img);
        if (src) allImgEls.push(img);
      });
      const existingSrcs = new Set(nodes.filter(n => n.type === "image").map(n => (n as { type: "image"; src: string }).src));
      allImgEls.forEach(img => {
        const src = getRealSrc(img);
        if (src && !existingSrcs.has(src)) nodes.push({ type: "image", src, alt: img.getAttribute("alt") || "" });
      });
    }
  }

  const base = new URL(currentUrl);
  const rp = parseReadParams(html);

  const resolve = (path?: string): string | null => {
    if (!path) return null;
    if (path.startsWith("http")) return path;
    return base.origin + path;
  };

  const nextUrl = resolve(rp.url_next);
  const prevUrl = resolve(rp.url_previous);

  const chapterBase = base.pathname.replace(/_\d+\.html$/, "").replace(/\.html$/, "");
  const isNextPageSameChapter = !!(nextUrl && (() => {
    try {
      const nextPath = new URL(nextUrl).pathname;
      return nextPath.replace(/_\d+\.html$/, "").replace(/\.html$/, "") === chapterBase
        && nextPath !== base.pathname;
    } catch { return false; }
  })());

  return { title, subtitle, nodes, nextUrl, prevUrl, isNextPageSameChapter };
}

type Theme = "dark" | "sepia" | "light";
type FontFamily = "sans" | "serif";

const FONT_MAP: Record<FontFamily, string> = {
  sans: "Arial, Helvetica, sans-serif",
  serif: '"Georgia", "Times New Roman", serif',
};

const LINE_HEIGHTS = [1.7, 1.95, 2.4] as const;

function ReadContent() {
  const params = useSearchParams();
  const router = useRouter();
  const chapterUrl = params.get("url") || "";
  const catalogUrl = params.get("catalog") || "";

  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [nodes, setNodes] = useState<ContentNode[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState("");
  const [fontSize, setFontSize] = useState(17);
  const [progress, setProgress] = useState(0);
  const [nextUrl, setNextUrl] = useState<string | null>(null);
  const [prevUrl, setPrevUrl] = useState<string | null>(null);
  const [nextTitle, setNextTitle] = useState("");
  const [prevTitle, setPrevTitle] = useState("");

  // Theme
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window === "undefined") return "dark";
    return (localStorage.getItem("linovelib-theme") as Theme) ?? "dark";
  });

  // Font family
  const [fontFamily, setFontFamily] = useState<FontFamily>(() => {
    if (typeof window === "undefined") return "sans";
    return (localStorage.getItem("linovelib-font") as FontFamily) ?? "sans";
  });

  // Line height
  const [lineHeightIdx, setLineHeightIdx] = useState(1); // default 1.95

  // Bookmarks
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);

  const contentRef = useRef<HTMLDivElement>(null);
  const touchStart = useRef<{ x: number; y: number } | null>(null);

  // Apply theme to document
  useEffect(() => {
    if (theme === "dark") {
      delete document.documentElement.dataset.theme;
    } else {
      document.documentElement.dataset.theme = theme;
    }
    localStorage.setItem("linovelib-theme", theme);
  }, [theme]);

  // Persist font family
  useEffect(() => {
    localStorage.setItem("linovelib-font", fontFamily);
  }, [fontFamily]);

  // Load bookmarks when chapterUrl changes
  useEffect(() => {
    if (chapterUrl) {
      setBookmarks(getBookmarksForChapter(chapterUrl));
    }
  }, [chapterUrl]);

  // Scroll progress
  useEffect(() => {
    const handleScroll = () => {
      const el = contentRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const total = el.offsetHeight - window.innerHeight;
      if (total <= 0) { setProgress(100); return; }
      const scrolled = -rect.top;
      setProgress(Math.min(100, Math.max(0, Math.round((scrolled / total) * 100))));
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (loading || loadingMore) return;
      if (e.key === "ArrowLeft" && prevUrl) goChapter(prevUrl);
      if (e.key === "ArrowRight" && nextUrl) goChapter(nextUrl);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, loadingMore, prevUrl, nextUrl]);

  useEffect(() => {
    if (!chapterUrl) return;
    let cancelled = false;

    setLoading(true);
    setLoadingMore(false);
    setNodes([]);
    setSubtitle("");
    setError("");
    setNextUrl(null);
    setPrevUrl(null);
    setNextTitle("");
    setPrevTitle("");
    window.scrollTo(0, 0);

    async function fetchAll() {
      let url: string | null = chapterUrl;
      let pageCount = 0;
      let chapterTitle = "";
      let finalNext: string | null = null;
      let finalPrev: string | null = null;

      while (url && pageCount < 20) {
        if (cancelled) return;

        const html = await fetchHtml(url);
        if (cancelled) return;

        const parsed = parseChapterPage(html, url);

        if (pageCount === 0) {
          chapterTitle = parsed.title;
          finalPrev = parsed.prevUrl;
          setTitle(chapterTitle);
          setSubtitle(parsed.subtitle);
          document.title = `${chapterTitle} — 輕小說閱讀器`;
          setPrevUrl(finalPrev);
          setPrevTitle(finalPrev ? getCachedChapterTitle(finalPrev) : "");
          setNodes(parsed.nodes);
          setLoading(false);
          if (parsed.isNextPageSameChapter) setLoadingMore(true);
        } else {
          setNodes(prev => [...prev, ...parsed.nodes]);
        }

        if (parsed.isNextPageSameChapter) {
          url = parsed.nextUrl;
          await new Promise(r => setTimeout(r, 400));
        } else {
          finalNext = parsed.nextUrl;
          url = null;
        }
        pageCount++;
      }

      if (cancelled) return;
      setLoadingMore(false);
      setNextUrl(finalNext);
      setNextTitle(finalNext ? getCachedChapterTitle(finalNext) : "");

      // Background-prefetch next chapter
      if (finalNext) {
        fetchHtml(finalNext).then(html => {
          if (cancelled) return;
          const { title: t, nextUrl: nextNextUrl, isNextPageSameChapter } = parseChapterPage(html, finalNext!);
          if (t) setNextTitle(t);
          // Prefetch 2 chapters ahead
          if (nextNextUrl && !isNextPageSameChapter) {
            fetchHtml(nextNextUrl).catch(() => {});
          }
        }).catch(() => {});
      }

      if (catalogUrl && chapterTitle) {
        const existing = getEntryFor(catalogUrl);
        saveProgress({
          catalogUrl,
          novelTitle: existing?.novelTitle || "",
          coverUrl: existing?.coverUrl || "",
          lastChapterUrl: chapterUrl,
          lastChapterTitle: chapterTitle,
          lastChapterIndex: existing?.lastChapterIndex ?? 0,
          totalChapters: existing?.totalChapters ?? 0,
          updatedAt: Date.now(),
          visitedChapters: existing?.visitedChapters ?? {},
        });
        markChapterVisited(catalogUrl, chapterUrl, chapterTitle);
      }
    }

    fetchAll().catch(e => {
      if (!cancelled) { setError(String(e)); setLoading(false); setLoadingMore(false); }
    });

    return () => { cancelled = true; };
  }, [chapterUrl, catalogUrl]);

  const goBack = () => {
    if (catalogUrl) router.push(`/catalog?url=${encodeURIComponent(catalogUrl)}`);
    else router.push("/");
  };

  const goChapter = (url: string) => {
    router.push(`/read?url=${encodeURIComponent(url)}&catalog=${encodeURIComponent(catalogUrl)}`);
  };

  const cycleTheme = () => {
    setTheme(t => t === "dark" ? "sepia" : t === "sepia" ? "light" : "dark");
  };

  const themeIcon = theme === "dark" ? "☀" : theme === "sepia" ? "📜" : "🌙";

  const cycleFontFamily = () => {
    setFontFamily(f => f === "sans" ? "serif" : "sans");
  };

  // Label shows NEXT option
  const fontLabel = fontFamily === "sans" ? "宋" : "黑";

  const cycleLineHeight = () => {
    setLineHeightIdx(i => (i + 1) % LINE_HEIGHTS.length);
  };

  const currentLineHeight = LINE_HEIGHTS[lineHeightIdx];

  const handleAddBookmark = () => {
    const bm = addBookmark({
      catalogUrl,
      novelTitle: title,
      chapterUrl,
      chapterTitle: title,
      scrollPct: progress,
    });
    setBookmarks(prev => [bm, ...prev]);
  };

  const handleRemoveBookmark = (id: string) => {
    removeBookmark(id);
    setBookmarks(prev => prev.filter(b => b.id !== id));
  };

  const scrollToBookmark = (scrollPct: number) => {
    window.scrollTo({
      top: (scrollPct / 100) * (document.body.scrollHeight - window.innerHeight),
      behavior: "smooth",
    });
  };

  const btnStyle: React.CSSProperties = {
    background: "var(--surface)",
    border: "1px solid var(--border)",
    color: "var(--text-muted)",
    padding: "6px 13px",
    borderRadius: 20,
    fontSize: 12,
  };

  return (
    <main
      style={{ minHeight: "100vh" }}
      ref={contentRef}
      onTouchStart={e => {
        touchStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }}
      onTouchEnd={e => {
        if (!touchStart.current) return;
        const dx = e.changedTouches[0].clientX - touchStart.current.x;
        const dy = e.changedTouches[0].clientY - touchStart.current.y;
        touchStart.current = null;
        if (Math.abs(dx) > 50 && Math.abs(dy) < Math.abs(dx)) {
          if (dx < 0 && nextUrl && !loading && !loadingMore) goChapter(nextUrl);
          if (dx > 0 && prevUrl && !loading && !loadingMore) goChapter(prevUrl);
        }
      }}
    >
      {/* Progress bar */}
      <div style={{ position: "fixed", top: 0, left: 0, right: 0, height: 2, background: "var(--border)", zIndex: 20 }}>
        <div style={{ height: "100%", background: "var(--accent)", width: `${progress}%`, transition: "width .2s" }} />
      </div>

      {/* Toolbar */}
      <div style={{ position: "sticky", top: 0, zIndex: 10, background: "linear-gradient(to bottom, var(--bg) 55%, transparent)", padding: "12px 20px 32px", pointerEvents: "none" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", pointerEvents: "all" }}>
          <button onClick={goBack} style={btnStyle}>
            ← 目錄
          </button>
          <div style={{ display: "flex", gap: 6 }}>
            <button onClick={() => setFontSize(f => Math.max(14, f - 1))} style={btnStyle}>A−</button>
            <button onClick={() => setFontSize(f => Math.min(26, f + 1))} style={btnStyle}>A+</button>
            <button onClick={cycleFontFamily} style={btnStyle} title="切換字體">{fontLabel}</button>
            <button onClick={cycleLineHeight} style={btnStyle} title="切換行距">≡</button>
            <button onClick={cycleTheme} style={btnStyle} title="切換主題">{themeIcon}</button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 660, margin: "0 auto", padding: "0 24px" }}>
        {!loading && !error && (
          <div style={{ textAlign: "center", marginBottom: 32 }}>
            {subtitle && (
              <div style={{ fontSize: 12, letterSpacing: ".12em", textTransform: "uppercase", color: "var(--text-dim)", marginBottom: 6, opacity: .75 }}>
                {subtitle}
              </div>
            )}
            <h2 style={{ fontSize: 20, fontWeight: 700, color: "var(--accent)", lineHeight: 1.4 }}>{title}</h2>
            <div style={{ width: 36, height: 1, background: "var(--accent-dim)", margin: "12px auto 0" }} />
          </div>
        )}

        {loading && <div style={{ color: "var(--accent)", textAlign: "center", padding: "80px 0" }}>載入中…</div>}
        {error && <div style={{ color: "#e06c6c", textAlign: "center", padding: "80px 0" }}>載入失敗：{error}</div>}

        {!loading && !error && nodes.length === 0 && (
          <div style={{ color: "var(--text-muted)", textAlign: "center", padding: "80px 0" }}>
            無法解析章節內容（#acontent 未找到）
          </div>
        )}

        {!loading && !error && (
          <div style={{ fontSize: `${fontSize}px`, lineHeight: currentLineHeight, color: "var(--text)", fontFamily: FONT_MAP[fontFamily] }}>
            {nodes.map((node, i) =>
              node.type === "text" ? (
                <p key={i} style={{ marginBottom: "1.5em", textIndent: "2em" }}>{node.text}</p>
              ) : (
                <div key={i} style={{ textAlign: "center", margin: "2em 0" }}>
                  <img
                    src={IMAGE_PROXY(node.src)}
                    alt={node.alt}
                    loading="lazy"
                    style={{ maxWidth: "100%", maxHeight: 480, objectFit: "contain", borderRadius: 6, border: "1px solid var(--border)" }}
                  />
                </div>
              )
            )}
          </div>
        )}

        {loadingMore && (
          <div style={{ textAlign: "center", padding: "24px 0", color: "var(--text-dim)", fontSize: 13 }}>
            載入後續頁面中…
          </div>
        )}

        {!loading && !error && !loadingMore && (
          <div style={{ borderTop: "1px solid var(--border)", marginTop: 60, padding: "24px 0 56px", display: "flex", alignItems: "stretch", justifyContent: "space-between", gap: 10 }}>
            <button
              onClick={() => prevUrl && goChapter(prevUrl)}
              disabled={!prevUrl}
              style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "12px 16px", display: "flex", flexDirection: "column", gap: 4, flex: 1, maxWidth: 200, opacity: prevUrl ? 1 : 0.3, textAlign: "left" }}
            >
              <span style={{ fontSize: 11, color: "var(--text-dim)" }}>← 上一章</span>
              <span style={{ fontSize: 13, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 150 }}>{prevTitle || "上一章"}</span>
            </button>
            <button onClick={goBack} style={{ background: "none", border: "none", color: "var(--text-muted)", fontSize: 12, padding: "8px", whiteSpace: "nowrap", alignSelf: "center" }}>
              目錄
            </button>
            <button
              onClick={() => nextUrl && goChapter(nextUrl)}
              disabled={!nextUrl}
              style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "12px 16px", display: "flex", flexDirection: "column", gap: 4, flex: 1, maxWidth: 200, opacity: nextUrl ? 1 : 0.3, alignItems: "flex-end" }}
            >
              <span style={{ fontSize: 11, color: "var(--text-dim)" }}>下一章 →</span>
              <span style={{ fontSize: 13, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 150 }}>{nextTitle || "下一章"}</span>
            </button>
          </div>
        )}
      </div>

      {/* Floating bookmark button */}
      <div style={{ position: "fixed", bottom: 80, right: 20, display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8, zIndex: 30 }}>
        {/* Bookmark pills */}
        {bookmarks.length > 0 && (
          <div style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: "flex-end" }}>
            {bookmarks.map(bm => (
              <div key={bm.id} style={{ display: "flex", alignItems: "center", gap: 6, background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 20, padding: "4px 10px", fontSize: 12, color: "var(--text-muted)" }}>
                <button
                  onClick={() => scrollToBookmark(bm.scrollPct)}
                  style={{ background: "none", border: "none", color: "var(--accent)", fontSize: 12, padding: 0 }}
                >
                  {bm.scrollPct}%
                </button>
                <button
                  onClick={() => handleRemoveBookmark(bm.id)}
                  style={{ background: "none", border: "none", color: "var(--text-dim)", fontSize: 12, padding: 0, lineHeight: 1 }}
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Bookmark add button */}
        <button
          onClick={handleAddBookmark}
          style={{
            width: 44,
            height: 44,
            borderRadius: "50%",
            background: "var(--surface)",
            border: "1px solid var(--border)",
            color: "var(--text)",
            fontSize: 18,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            position: "relative",
            boxShadow: "0 2px 8px rgba(0,0,0,.3)",
          }}
          title="新增書籤"
        >
          🔖
          {bookmarks.length > 0 && (
            <span style={{
              position: "absolute",
              top: -4,
              right: -4,
              background: "var(--accent)",
              color: "var(--bg)",
              borderRadius: "50%",
              width: 16,
              height: 16,
              fontSize: 10,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 700,
            }}>
              {bookmarks.length}
            </span>
          )}
        </button>
      </div>
    </main>
  );
}

export default function ReadPage() {
  return <Suspense><ReadContent /></Suspense>;
}
