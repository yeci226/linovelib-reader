# linovelib-reader

Next.js 前端 + FlareSolverr 處理 Cloudflare 的輕小說閱讀器。

## 架構

```
瀏覽器 → Next.js (app/api/*) → cfFetchHtml()
                                  │
                                  ├─ 有 cache cookie? → 直接 fetch
                                  └─ 沒有 / cookie 過期 → POST FlareSolverr:8191
                                                          (headless Chromium 過 CF)
```

- **FlareSolverr** 跑在 Docker，專責解 Cloudflare challenge
- 解過一次後 cookies 快取 20 分鐘，期間直接 fetch 跳過 CF
- 章節內容寫入 `.cache/chapter/` 永不過期；目錄寫 `.cache/catalog/` TTL 1 天

## 本機開發

需要 Docker Desktop。

```bash
# 1. 起 FlareSolverr (背景)
docker compose up -d

# 健康檢查 — 應該回 {"msg":"FlareSolverr is ready!"}
curl http://localhost:8191/

# 2. 起 Next.js
npm install
npm run dev
```

開 http://localhost:3000

## 環境變數

| 變數 | 預設 | 說明 |
|---|---|---|
| `FLARESOLVERR_URL` | `http://localhost:8191/v1` | FlareSolverr 端點 |

## 驗證能不能過 CF

直接打 API：

```bash
# 章節：第一次會走 FlareSolverr (慢，5-15s)，第二次走 cache (瞬間)
curl "http://localhost:3000/api/chapter?url=https://www.linovelib.com/novel/2139/76673.html"

# 強制重抓（忽略 file cache）
curl "http://localhost:3000/api/chapter?url=...&refresh=1"
```

回傳 JSON 含 `cached: true|false` 可以判斷來源。

## 清快取

```bash
rm -rf .cache/
```

## 之後要部署到 VPS

`docker-compose.yml` 加一個 service 跑 Next.js，兩個容器共網路即可（`FLARESOLVERR_URL=http://flaresolverr:8191/v1`）。記得加 rate limit / 基本 auth，否則 IP 可能被 linovelib ban 整台。
